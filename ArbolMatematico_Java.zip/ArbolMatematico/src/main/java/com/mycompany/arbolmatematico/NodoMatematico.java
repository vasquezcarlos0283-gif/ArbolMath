package com.mycompany.arbolmatematico;

/**
 * Clase NodoMatematico
 * Representa cada nodo del árbol binario.
 */
public class NodoMatematico {

    //Valor almacenado en el nodo.
    String valor;

    //Referencia al hijo izquierdo.
    NodoMatematico izquierda;

    //Referencia al hijo derecho.
    NodoMatematico derecha;

    //Constructor del nodo.
    public NodoMatematico(String valor) {

        //Asigna el valor recibido.
        this.valor = valor;

        //Inicializa referencias vacías.
        this.izquierda = null;
        this.derecha = null;

    }

}