package com.mycompany.arbolmatematico;

//Clase encargada de construir y evaluar árboles matemáticos.
public class ArbolMatematico {

    //Construye el árbol matemático a partir de una expresión.
    public static NodoMatematico construirArbol(
            String expresion) {

        //Elimina espacios en blanco.
        expresion =
                expresion.replace(" ", "");

        //Verifica que exista una expresión.
        if (expresion.isEmpty()) {

            return null;

        }

        //Inicia la construcción recursiva.
        return construirRecursivo(
                expresion);

    }

    //Construye recursivamente el árbol de expresión.
    private static NodoMatematico construirRecursivo(
            String expresion) {

        //Elimina paréntesis externos innecesarios.
        expresion =
                eliminarParentesisExternos(
                        expresion);

        //Busca el operador principal.
        int posicion =
                buscarOperadorPrincipal(
                        expresion);

        //Si no existe operador se trata de un operando.
        if (posicion == -1) {

            return new NodoMatematico(
                    expresion);

        }

        //Obtiene el operador principal.
        char operador =
                expresion.charAt(
                        posicion);

        //Crea la raíz de la subexpresión.
        NodoMatematico raiz =
                new NodoMatematico(
                        String.valueOf(
                                operador));

        //Construye el subárbol izquierdo.
        raiz.izquierda =
                construirRecursivo(
                        expresion.substring(
                                0,
                                posicion));

        //Construye el subárbol derecho.
        raiz.derecha =
                construirRecursivo(
                        expresion.substring(
                                posicion + 1));

        return raiz;

    }

    //Busca el operador principal respetando prioridad y paréntesis.
    private static int buscarOperadorPrincipal(
            String expresion) {

        int nivel = 0;

        //Busca operadores de menor prioridad.
        for (int i =
                expresion.length() - 1;
                i >= 0;
                i--) {

            char c =
                    expresion.charAt(i);

            //Control de profundidad de paréntesis.
            if (c == ')') {

                nivel++;

            } else if (c == '(') {

                nivel--;

            }

            //Busca suma o resta fuera de paréntesis.
            else if (nivel == 0
                    && (c == '+'
                    || c == '-')) {

                return i;

            }

        }

        nivel = 0;

        //Busca multiplicación o división.
        for (int i =
                expresion.length() - 1;
                i >= 0;
                i--) {

            char c =
                    expresion.charAt(i);

            //Control de profundidad de paréntesis.
            if (c == ')') {

                nivel++;

            } else if (c == '(') {

                nivel--;

            }

            //Busca multiplicación o división.
            else if (nivel == 0
                    && (c == '*'
                    || c == '/')) {

                return i;

            }

        }

        //No se encontró operador.
        return -1;

    }

    //Elimina paréntesis externos redundantes.
    private static String eliminarParentesisExternos(
            String expresion) {

        while (expresion.startsWith("(")
                && expresion.endsWith(")")
                && parentesisBalanceados(
                        expresion.substring(
                                1,
                                expresion.length() - 1))) {

            expresion =
                    expresion.substring(
                            1,
                            expresion.length() - 1);

        }

        return expresion;

    }

    //Comprueba que los paréntesis estén correctamente balanceados.
    public static boolean parentesisBalanceados(
            String expresion) {

        int contador = 0;

        for (int i = 0;
                i < expresion.length();
                i++) {

            char c =
                    expresion.charAt(i);

            //Cuenta paréntesis de apertura.
            if (c == '(') {

                contador++;

            }

            //Cuenta paréntesis de cierre.
            if (c == ')') {

                contador--;

            }

            //Detecta cierre sin apertura.
            if (contador < 0) {

                return false;

            }

        }

        //Valida que todos estén cerrados.
        return contador == 0;

    }

    //Evalúa recursivamente el árbol matemático.
    public static double evaluar(
            NodoMatematico nodo) {

        //Caso base: nodo hoja.
        if (nodo.izquierda == null
                && nodo.derecha == null) {

            return Double.parseDouble(
                    nodo.valor);

        }

        //Obtiene valor izquierdo.
        double izquierda =
                evaluar(
                        nodo.izquierda);

        //Obtiene valor derecho.
        double derecha =
                evaluar(
                        nodo.derecha);

        //Evalúa la operación correspondiente.
        switch (nodo.valor) {

            case "+":
                return izquierda + derecha;

            case "-":
                return izquierda - derecha;

            case "*":
                return izquierda * derecha;

            case "/":

                //Evita división entre cero.
                if (derecha == 0) {

                    throw new ArithmeticException(
                            "Division entre cero");

                }

                return izquierda / derecha;

            default:

                throw new IllegalArgumentException(
                        "Operador invalido");

        }

    }

}