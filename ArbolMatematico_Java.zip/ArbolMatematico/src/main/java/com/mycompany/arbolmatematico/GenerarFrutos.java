package com.mycompany.arbolmatematico;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

//Clase encargada de mostrar la interfaz gráfica para capturar y evaluar expresiones matemáticas.
public class GenerarFrutos extends JFrame {

    //Campo para ingresar la expresión matemática.
    private JTextField txtExpresion;

    //Botón para calcular el resultado.
    private JButton btnCalcular;

    //Botón para limpiar la interfaz.
    private JButton btnReiniciar;

    //Etiqueta que muestra el resultado.
    private JLabel lblResultado;

    //Área donde se muestra el árbol generado.
    private JTextArea txtArbol;

    //Constructor de la ventana principal.
    public GenerarFrutos() {

        //Configuración básica de la ventana.
        setTitle("GENERAR FRUTOS");
        setSize(950, 750);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        //Inicializa todos los componentes gráficos.
        inicializarComponentes();
    }

    //Crea y configura los componentes de la interfaz.
    private void inicializarComponentes() {

        //Título principal de la ventana.
        JLabel lblTitulo =
                new JLabel(
                        "Ingresa la expresión matemática que deseas evaluar",
                        SwingConstants.CENTER);

        lblTitulo.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        32));

        //Campo para capturar la expresión.
        txtExpresion =
                new JTextField();

        txtExpresion.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        28));

        txtExpresion.setBorder(
                BorderFactory.createTitledBorder(
                        "Entrada Algebraica"));

        //Botón encargado de calcular.
        btnCalcular =
                new JButton(
                        "Calcular ahora");

        btnCalcular.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        26));

        btnCalcular.setPreferredSize(
                new Dimension(
                        220,
                        45));

        //Botón encargado de reiniciar la interfaz.
        btnReiniciar =
                new JButton(
                        "Limpiar");

        btnReiniciar.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        26));

        btnReiniciar.setPreferredSize(
                new Dimension(
                        180,
                        45));

        //Etiqueta donde se mostrará el resultado final.
        lblResultado =
                new JLabel(
                        "Expresión Evaluada:",
                        SwingConstants.CENTER);

        lblResultado.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        32));

        //Área destinada a mostrar la estructura del árbol.
        txtArbol =
                new JTextArea();

        txtArbol.setEditable(
                false);

        txtArbol.setFont(
                new Font(
                        "Consolas",
                        Font.PLAIN,
                        24));

        txtArbol.setBorder(
                BorderFactory.createTitledBorder(
                        "Árbol de operaciones"));

        //Panel con desplazamiento para el árbol.
        JScrollPane scroll =
                new JScrollPane(
                        txtArbol);

        //Panel principal superior.
        JPanel panelSuperior =
                new JPanel(
                        new BorderLayout(
                                10,
                                10));

        //Agrega el título.
        panelSuperior.add(
                lblTitulo,
                BorderLayout.NORTH);

        //Agrega el campo de captura.
        panelSuperior.add(
                txtExpresion,
                BorderLayout.CENTER);

        //Panel para contener los botones.
        JPanel panelBotones =
                new JPanel();

        //Agrega los botones al panel.
        panelBotones.add(
                btnCalcular);

        panelBotones.add(
                btnReiniciar);

        panelSuperior.add(
                panelBotones,
                BorderLayout.SOUTH);

        //Agrega componentes a la ventana.
        add(
                panelSuperior,
                BorderLayout.NORTH);

        add(
                lblResultado,
                BorderLayout.CENTER);

        add(
                scroll,
                BorderLayout.SOUTH);

        //Evento para calcular la expresión.
        btnCalcular.addActionListener(
                e -> calcular());

        //Evento para reiniciar la interfaz.
        btnReiniciar.addActionListener(
                e -> reiniciar());
    }

    //Valida, construye y evalúa la expresión matemática.
    private void calcular() {

        try {

            //Obtiene la expresión ingresada.
            String expresion =
                    txtExpresion.getText()
                            .trim();

            //Verifica que exista una expresión.
            if (expresion.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Ingrese una expresión.");

                return;
            }

            //Valida que los paréntesis estén balanceados.
            if (!ArbolMatematico
                    .parentesisBalanceados(
                            expresion)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Paréntesis no balanceados.");

                return;
            }

            //Construye el árbol de expresión.
            NodoMatematico raiz =
                    ArbolMatematico
                            .construirArbol(
                                    expresion);

            //Evalúa el árbol matemático.
            double resultado =
                    ArbolMatematico
                            .evaluar(
                                    raiz);

            //Muestra el resultado al usuario.
            lblResultado.setText(
                    "Resultado: "
                            + resultado);

            //Limpia el árbol anterior.
            txtArbol.setText("");

            //Muestra el nuevo árbol generado.
            imprimirArbol(
                    raiz,
                    0);

        } catch (Exception ex) {

            //Muestra cualquier error detectado.
            JOptionPane.showMessageDialog(
                    this,
                    "Error: "
                    + ex.getMessage());
        }
    }

    //Limpia la interfaz para realizar un nuevo cálculo.
    private void reiniciar() {

        txtExpresion.setText("");

        lblResultado.setText(
                "Resultado:");

        txtArbol.setText("");

        txtExpresion.requestFocus();
    }

    //Imprime la estructura del árbol matemático.
    private void imprimirArbol(
            NodoMatematico nodo,
            int nivel) {

        //Caso base de la recursividad.
        if (nodo == null) {

            return;
        }

        //Genera la sangría según el nivel.
        for (int i = 0;
                i < nivel;
                i++) {

            txtArbol.append(
                    "   ");
        }

        //Muestra el valor del nodo actual.
        txtArbol.append(
                nodo.valor + "\n");

        //Recorre el subárbol izquierdo.
        imprimirArbol(
                nodo.izquierda,
                nivel + 1);

        //Recorre el subárbol derecho.
        imprimirArbol(
                nodo.derecha,
                nivel + 1);
    }

    //Método principal del programa.
    public static void main(
            String[] args) {

        //Inicia la interfaz gráfica.
        SwingUtilities.invokeLater(
                () -> {

                    new GenerarFrutos()
                            .setVisible(true);
                });
    }
}